Étape 09 : construction de l'index STAR sjdbOverhang 149.

Le résultat principal n'est pas stocké dans results/,
mais dans :

~/work/reference/star_index_sjdb149

Script utilisé :
~/work/analysis_all/scripts/09_star_index_sjdb149.sh

Logs :
~/work/analysis_all/logs/09_star_index_sjdb149
