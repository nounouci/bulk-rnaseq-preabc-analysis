INPUTS POUR OUTILS ONLINE
=========================

1. GenePattern / GSEAPreranked
------------------------------
Uploader ce fichier comme ranked list :
GenePattern_GSEA/PreABC_vs_Neg_DESeq2_stat_SYMBOL.rnk

Paramètres GenePattern recommandés :
- Module : GSEAPreranked
- Ranking metric : stat DESeq2
- Score positif : enrichissement côté PreABC
- Score négatif : enrichissement côté Neg
- Permutation type : gene_set
- Number of permutations : 1000
- Min size : 10
- Max size : 1500
- Collapse : false / no collapse

GMT à utiliser avec GenePattern : fichiers *.symbols.gmt, par exemple :
- m2.cp.v2026.1.Mm.symbols.gmt
- m2.cp.reactome.v2026.1.Mm.symbols.gmt
- m2.cp.wikipathways.v2026.1.Mm.symbols.gmt
- m2.cp.biocarta.v2026.1.Mm.symbols.gmt
- m5.go.bp.v2026.1.Mm.symbols.gmt
- m5.go.cc.v2026.1.Mm.symbols.gmt
- m5.go.mf.v2026.1.Mm.symbols.gmt
- mh.all.v2026.1.Mm.symbols.gmt
- m7.all.v2026.1.Mm.symbols.gmt
- m8.all.v2026.1.Mm.symbols.gmt

2. Enrichr
----------
Uploader/copier une liste de gènes depuis le dossier Enrichr.
Priorité :
- Enrichr/UP_PreABC_padj005.txt
- Enrichr/DOWN_PreABC_padj005.txt
- Enrichr/ALL_DEG_padj005.txt

3. Metascape
------------
Uploader plusieurs listes depuis Metascape :
- UP_PreABC_padj005.txt
- DOWN_PreABC_padj005.txt
- UP_PreABC_padj005_log2FC1.txt
- DOWN_PreABC_padj005_log2FC1.txt
Species : Mus musculus
Background si demandé : Background/BACKGROUND_expressed_genes_SYMBOL.txt

4. Reactome
-----------
Uploader surtout :
- Reactome/UP_PreABC_padj005.txt
- Reactome/DOWN_PreABC_padj005.txt
Puis éventuellement les listes strictes log2FC1.

IMPORTANT
---------
Utiliser les GMT *.symbols.gmt car les listes sont en symboles de gènes souris.
Ne pas utiliser *.entrez.gmt sauf si une conversion en Entrez ID a été faite.
