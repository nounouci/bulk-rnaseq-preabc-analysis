#!/bin/bash

#SBATCH -J nfcore_AM_Stim_Bi_Mono
#SBATCH -o nfcore_AM_Stim_Bi_Mono-%A.out
#SBATCH -e nfcore_AM_Stim_Bi_Mono-%A.err
#SBATCH -p workq
#SBATCH --mem=8G
#SBATCH -c 2
#SBATCH --time=4-00:00:00

module purge
module load bioinfo/NextflowWorkflows/nfcore-Nextflow-v24.04.2

cd ~/work/analysis_all

nextflow run nf-core/rnaseq \
  -r 3.18.0 \
  --input samplesheet_AM_Stim_Bi_Mono.csv \
  --outdir results/26_nfcore_rnaseq_AM_Stim_Bi_Mono \
  --fasta /home/neddassouqu/work/reference/Mus_musculus.GRCm39.dna.toplevel.fa \
  --gtf /home/neddassouqu/work/reference/Mus_musculus.GRCm39.109.gtf \
  --aligner star_salmon \
  --seq_platform ILLUMINA \
  --featurecounts_group_type gene_biotype \
  --skip_bigwig \
  --remove_ribo_rna \
  --skip_markduplicates \
  --skip_stringtie \
  --skip_dupradar \
  -profile genotoul \
  -resume \
  -with-report results/26_nfcore_rnaseq_AM_Stim_Bi_Mono/nextflow_report.html \
  -with-trace results/26_nfcore_rnaseq_AM_Stim_Bi_Mono/nextflow_trace.txt \
  -with-timeline results/26_nfcore_rnaseq_AM_Stim_Bi_Mono/nextflow_timeline.html
