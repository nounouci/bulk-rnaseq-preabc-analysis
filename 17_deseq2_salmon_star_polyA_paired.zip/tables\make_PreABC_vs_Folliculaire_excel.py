import pandas as pd
import numpy as np

input_file = "DESeq2_PreABC_vs_Neg_STAR_paired_all_genes.csv"
output_file = "DESeq2_PreABC_vs_Folliculaire_interpretation.xlsx"

df = pd.read_csv(input_file)

# Vérifier que la colonne log2FoldChange existe
if "log2FoldChange" not in df.columns:
    raise ValueError("La colonne 'log2FoldChange' est introuvable dans le fichier.")

# Si padj n'existe pas, erreur
if "padj" not in df.columns:
    raise ValueError("La colonne 'padj' est introuvable dans le fichier.")

# Fold change normal : FC = 2^log2FC
df["FoldChange_PreABC_vs_Folliculaire"] = 2 ** df["log2FoldChange"]

# Interprétation simple du sens d'expression
df["Expression_plus_forte_dans"] = np.where(
    df["log2FoldChange"] > 0,
    "PreABC",
    np.where(df["log2FoldChange"] < 0, "Folliculaire/Neg", "Aucun changement")
)

# Statut avec seuil padj < 0.05 et |log2FC| >= 1
conditions = [
    (df["padj"] < 0.05) & (df["log2FoldChange"] >= 1),
    (df["padj"] < 0.05) & (df["log2FoldChange"] <= -1),
    (df["padj"] < 0.05) & (df["log2FoldChange"].abs() < 1),
]

choices = [
    "UP dans PreABC / DOWN dans Folliculaire",
    "DOWN dans PreABC / UP dans Folliculaire",
    "Significatif mais faible fold change"
]

df["Interpretation"] = np.select(conditions, choices, default="Non significatif")

# Tables séparées
up_preabc = df[(df["padj"] < 0.05) & (df["log2FoldChange"] >= 1)].copy()
up_folliculaire = df[(df["padj"] < 0.05) & (df["log2FoldChange"] <= -1)].copy()
significant_all = df[df["padj"] < 0.05].copy()
significant_log2fc1 = df[(df["padj"] < 0.05) & (df["log2FoldChange"].abs() >= 1)].copy()

# Trier par padj
df = df.sort_values("padj", na_position="last")
up_preabc = up_preabc.sort_values("padj", na_position="last")
up_folliculaire = up_folliculaire.sort_values("padj", na_position="last")
significant_all = significant_all.sort_values("padj", na_position="last")
significant_log2fc1 = significant_log2fc1.sort_values("padj", na_position="last")

with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
    df.to_excel(writer, sheet_name="Tous_les_genes", index=False)
    significant_all.to_excel(writer, sheet_name="Significatifs_padj005", index=False)
    significant_log2fc1.to_excel(writer, sheet_name="Signif_padj005_log2FC1", index=False)
    up_preabc.to_excel(writer, sheet_name="UP_PreABC", index=False)
    up_folliculaire.to_excel(writer, sheet_name="UP_Folliculaire", index=False)

print(f"Fichier créé : {output_file}")
print(f"Nombre total de gènes : {len(df)}")
print(f"Gènes significatifs padj < 0.05 : {len(significant_all)}")
print(f"UP dans PreABC : {len(up_preabc)}")
print(f"UP dans Folliculaire/Neg : {len(up_folliculaire)}")
